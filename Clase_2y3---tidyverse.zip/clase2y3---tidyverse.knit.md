---
title: "Procesando datos con el paquete tidyverse"
subtitle: "Diplomatura en Ciencias Sociales Computacionales y Humanidades Digitales"
output:
  xaringan::moon_reader:
    self_contained: true
    css: [default, metropolis, metropolis-fonts]
    lib_dir: libs
    nature:
      ratio: 16:9
      highlightStyle: github
      highlightLines: true
      highlightSpans: true
      countIncrementalSlides: false
---
